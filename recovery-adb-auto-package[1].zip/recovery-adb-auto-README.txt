Infinix HOT 8 X650C / H626 — recovery ADB auto-start test image

File: recovery-adb-auto.img
Source: user-uploaded recovery.img
Patch: In init.recovery.mt6765.rc, changed the MediaTek recovery trigger from
  on property:ro.debuggable=0
  to
  on property:ro.debuggable=1

Purpose: align the MediaTek configfs ADB initialization trigger with this recovery
ramdisk's ro.debuggable=1 setting. The existing stock recovery UI, kernel, and
recovery_dtbo payload were preserved. This is a narrow experimental patch, not a
proof that USB ADB will work on-device; hardware/runtime testing is still required.

Validation:
- Android boot image header version: 1
- Image length: 33554432 bytes (same as source)
- Kernel payload: unchanged
- Ramdisk gzip: valid; uncompressed CPIO content verified
- Recovery DTBO: 42066 bytes at offset 16601088; unchanged
- AVB footer marker: present, but its cryptographic digest/signature may no longer
  validate because the image contents changed. This image has NOT been re-signed.

IMPORTANT SAFETY:
- Do not flash this image on a locked bootloader or where AVB verification is enforced.
- Keep the original recovery.img and a verified recovery/boot restoration method.
- Do not flash until you have confirmed bootloader state and a known-good recovery path.
- ADB authorization behavior and USB enumeration must be tested on the actual phone.
- This change targets recovery only; it does not enable ADB in normal Android.
