Infinix HOT 8 X650C / H626 — recovery image, version v5
=========================================================

Cumulative patches (all verified against the stock recovery.img):

1. MediaTek ADB auto-start (from recovery-adb-auto):
   init.recovery.mt6765.rc trigger "on property:ro.debuggable=0" -> "=1",
   so adbd starts in this ro.debuggable=1 recovery.

2. Embedded ADB authorized key:
   ramdisk /adb_keys contains your PC's public key (adbkey[1].pub,
   "AHMED@DESKTOP-6J676F2"). This PC connects instantly, no prompt.

3. Secure ADB enabled (new in v5):
   prop.default "ro.adb.secure=0" -> "=1".
   Behavior in recovery now:
     - your PC (key in /adb_keys): connects directly, no prompt
     - any other PC: stays "unauthorized" — no access, and (yet) no popup,
       because the on-screen authorize dialog needs the recovery_authd
       daemon planned in POPUP-AUTH-PLAN.md (future version). It will plug
       into exactly this config — no further prop changes needed then.

Unchanged from stock: kernel payload, recovery_dtbo (42066 bytes @ offset
16601088), AVB/vbmeta tail, image size 33554432 bytes, AVBf footer at EOF-64.
Header: only ramdisk_size and id[] updated (id recomputed mkbootimg-style).

sha256(recovery-v5.img):
  4f5128dfe9b568dab7fabecfcc930e8bda5bc0e8f4ad0e3c6e796050ae4fc189

SAFETY (unchanged): unsigned image — flash only with unlocked bootloader /
AVB verification off; keep the original recovery.img and a known-good
restore path. Recovery-only; normal Android boot is untouched.

Flash & test:
  fastboot flash recovery recovery-v5.img   # then boot to recovery
  adb devices    # from YOUR PC  -> "recovery" (ADB connected)
  # Do not use adb shell id as a connection test: this image has no shell.
  # adb pull /init.rc is also not a test: /init.rc is root:root 0750
  # and returns Permission denied on the tested device.
                 # from any other PC -> "unauthorized" (no popup in v5)

Shell limitation: the recovery ramdisk has no /system/bin/sh. If
`adb shell id` reports "exec '/system/bin/sh' failed: No such file
or directory", this is a missing shell, NOT a failed ADB connection.
A shell-capable recovery would need a separate, tested shell patch.
