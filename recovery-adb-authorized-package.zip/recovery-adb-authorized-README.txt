Infinix HOT 8 X650C / H626 — recovery image with embedded ADB authorization key

File: recovery-adb-authorized.img
Base: recovery-adb-auto.img (previous patch: MediaTek adb configfs trigger
  "on property:ro.debuggable=0" -> "=1" in init.recovery.mt6765.rc)

New patch: the ramdisk now contains /adb_keys with your PC's ADB public key
(the single line from adbkey[1].pub, ending in "AHMED@DESKTOP-6J676F2").
adbd reads /adb_keys at startup (adb_auth_init), so this PC is pre-authorized
when the phone is in recovery mode — no "Allow USB debugging" RSA confirmation
is needed (recovery cannot show that dialog). This also covers the case where
adbd runs with ro.adb.secure=1. Note: this ramdisk already ships
ro.adb.secure=0 / ro.debuggable=1, so the key is a belt-and-suspenders guarantee.

Validation of the repack:
- Android boot image header v1, page size 2048, header_size 1648
- Only ramdisk_size (7476083 -> 7470170) and id[] changed in the header;
  id[] recomputed the mkbootimg way (sha1 of kernel|size|ramdisk|size|second|size)
- Ramdisk: 147 -> 148 cpio entries; exactly one entry added (adb_keys, mode 0644);
  every pre-existing file is byte-identical
- Kernel payload: unchanged
- Recovery DTBO: 42066 bytes at offset 16601088; unchanged
- AVB/vbmeta tail from offset 16644096: byte-identical; AVBf footer still at EOF-64
- Image length: 33554432 bytes (same as source)
- sha256: 6d38401c12aa74764ef739a62f7a39badf4c91932393225261e1280256449b55

Repacked with a clean gzip -9 ramdisk, which is why the compressed ramdisk is
slightly smaller despite the added file; everything before/after it sits at the
same offsets.

IMPORTANT SAFETY (unchanged from previous package):
- Do not flash this image on a locked bootloader or where AVB verification is
  enforced. The image is NOT re-signed, so AVB digests over the ramdisk no
  longer match (hash parts in the vbmeta tail were left untouched).
- Keep the original recovery.img and a verified recovery/boot restoration method.
- Test on the actual phone: run `fastboot flash recovery recovery-adb-authorized.img`
  (or your usual flashing method), boot into recovery, then `adb devices` from
  the PC that owns this key. It should come up "device" without any auth prompt.
- This change targets recovery only; it does not change normal Android boot.
